package com.example.netflixdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetflixdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
